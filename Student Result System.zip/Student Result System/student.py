# REGISTER NEW STUDENT
print("\n-----------REGISTER NEW STUDENT-------------")
stu_id = input("\nENTER STUDENT ID:")
name = input("ENTER FULL NAME: ")
age = float(input("ENTER AGE: "))
Class = str(input("ENTER CLASS:"))
gender = input("ENTER GENDER:")

print("\nSTUDENT IDENTITY:" ,stu_id)
print("STUDENT NAME:" ,name)
print("STUDENT AGE:" ,age)
print("STUDENT CLASS:" ,Class)
print("STUDENT GENDER:" ,gender)

# SEARCH FOR EXISTING STUDENT
students = []
student = {
    "student_id": "001",
    "student_id": "002",
    "student_id": "003",
    "student_id": "004",
    "student_id": "005",
}
students.append(student)

print("\n---------------SEARCH FOR STUDENT------------------")
students = input("\nENTER STUDENT'S STUDENT'S ID:")

for student in students:
    if student["student_id"] == "001,002,003,004,005":
        print("student found")
else:
    print("student not found")



